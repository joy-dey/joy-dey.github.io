#!/usr/bin/env node
import{main as e}from"./main.js";process.title="marked",e(process);
